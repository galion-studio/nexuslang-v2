"""
NexusLang v2 Platform - Main API Server
FastAPI application with all unified services
"""

from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from contextlib import asynccontextmanager

from core.config import settings
from core.database import init_db
from api import auth, nexuslang, ide, grokopedia, voice, billing, community

# Lifespan context manager for startup/shutdown events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("🚀 Starting NexusLang v2 Platform...")
    try:
        await init_db()
        print("✅ Database initialized")
    except Exception as e:
        print(f"⚠️  Warning: Database initialization issue: {e}")
        print("   Server will still start, but database features may not work")
    yield
    # Shutdown
    print("👋 Shutting down NexusLang v2 Platform...")

# Create FastAPI app
app = FastAPI(
    title="NexusLang v2 API",
    description="Unified API for the NexusLang v2 Platform",
    version="2.0.0-beta",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware - Configure allowed origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check endpoint
@app.get("/health")
async def health_check():
    """
    Health check endpoint for monitoring.
    Returns service status and version info.
    """
    return {
        "status": "healthy",
        "service": "nexuslang-v2-api",
        "version": "2.0.0-beta"
    }

# Root endpoint
@app.get("/")
async def root():
    """
    Root endpoint with API information.
    """
    return {
        "message": "Welcome to NexusLang v2 API",
        "version": "2.0.0-beta",
        "docs": "/docs",
        "health": "/health"
    }

# Include routers for different services
app.include_router(auth.router, prefix="/api/v2/auth", tags=["Authentication"])
app.include_router(nexuslang.router, prefix="/api/v2/nexuslang", tags=["NexusLang"])
app.include_router(ide.router, prefix="/api/v2/ide", tags=["IDE"])
app.include_router(grokopedia.router, prefix="/api/v2/grokopedia", tags=["Grokopedia"])
app.include_router(voice.router, prefix="/api/v2/voice", tags=["Voice"])
app.include_router(billing.router, prefix="/api/v2/billing", tags=["Billing"])
app.include_router(community.router, prefix="/api/v2/community", tags=["Community"])

# WebSocket endpoint for real-time features
@app.websocket("/ws/{channel}")
async def websocket_endpoint(websocket: WebSocket, channel: str):
    """
    WebSocket endpoint for real-time communication.
    Supports: ide, voice, notifications, live-coding
    """
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_text()
            # Route to appropriate handler based on channel
            await websocket.send_text(f"Echo: {data}")
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        await websocket.close()

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"error": "Endpoint not found", "path": str(request.url)}
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"}
    )

if __name__ == "__main__":
    # Run the server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )


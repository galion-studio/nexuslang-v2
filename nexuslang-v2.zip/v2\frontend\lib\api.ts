/**
 * API Client for NexusLang v2 Backend
 * Handles all HTTP requests to the backend API with authentication
 */

// API base URL from environment or default to localhost
const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

/**
 * Get stored auth token from localStorage
 */
export function getToken(): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem('nexus_token')
}

/**
 * Store auth token in localStorage
 */
export function setToken(token: string): void {
  if (typeof window === 'undefined') return
  localStorage.setItem('nexus_token', token)
}

/**
 * Remove auth token from localStorage
 */
export function clearToken(): void {
  if (typeof window === 'undefined') return
  localStorage.removeItem('nexus_token')
}

/**
 * Base fetch wrapper with error handling
 */
async function apiFetch(
  endpoint: string,
  options: RequestInit = {}
): Promise<any> {
  const url = `${API_BASE}${endpoint}`
  
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    })
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ detail: response.statusText }))
      throw new Error(error.detail || error.message || 'API request failed')
    }
    
    return await response.json()
  } catch (error) {
    console.error('API Error:', error)
    throw error
  }
}

/**
 * Fetch with authentication
 */
async function authFetch(endpoint: string, options: RequestInit = {}): Promise<any> {
  const token = getToken()
  
  if (!token) {
    throw new Error('Not authenticated. Please login.')
  }
  
  return apiFetch(endpoint, {
    ...options,
    headers: {
      ...options.headers,
      Authorization: `Bearer ${token}`,
    },
  })
}

// ====== Authentication API ======

export interface RegisterData {
  email: string
  username: string
  password: string
  full_name?: string
}

export interface LoginData {
  email: string
  password: string
}

export interface TokenResponse {
  access_token: string
  token_type: string
  user_id: string
  email: string
  username: string
}

export interface User {
  id: string
  email: string
  username: string
  full_name?: string
  avatar_url?: string
  bio?: string
  is_verified: boolean
  created_at: string
}

export const auth = {
  /**
   * Register a new user account
   */
  register: async (data: RegisterData): Promise<TokenResponse> => {
    const result = await apiFetch('/api/v2/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    })
    // Auto-save token
    setToken(result.access_token)
    return result
  },
  
  /**
   * Login with email and password
   */
  login: async (data: LoginData): Promise<TokenResponse> => {
    const result = await apiFetch('/api/v2/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    })
    // Auto-save token
    setToken(result.access_token)
    return result
  },
  
  /**
   * Get current user info
   */
  me: async (): Promise<User> => {
    return await authFetch('/api/v2/auth/me')
  },
  
  /**
   * Logout (clears local token)
   */
  logout: () => {
    clearToken()
  },
  
  /**
   * Check if user is authenticated
   */
  isAuthenticated: (): boolean => {
    return getToken() !== null
  },
}

// ====== NexusLang Execution API ======

export interface ExecuteRequest {
  code: string
  compile_to_binary?: boolean
}

export interface ExecuteResponse {
  output: string
  execution_time: number
  success: boolean
  error?: string
}

export interface CompileResponse {
  success: boolean
  binary_size?: number
  compression_ratio?: number
  error?: string
}

export const nexuslang = {
  /**
   * Execute NexusLang code
   */
  run: async (code: string): Promise<ExecuteResponse> => {
    return await authFetch('/api/v2/nexuslang/run', {
      method: 'POST',
      body: JSON.stringify({ code }),
    })
  },
  
  /**
   * Compile code to binary
   */
  compile: async (code: string): Promise<CompileResponse> => {
    return await authFetch('/api/v2/nexuslang/compile', {
      method: 'POST',
      body: JSON.stringify({ code }),
    })
  },
  
  /**
   * Analyze code for errors
   */
  analyze: async (code: string): Promise<any> => {
    return await authFetch('/api/v2/nexuslang/analyze', {
      method: 'POST',
      body: JSON.stringify({ code }),
    })
  },
  
  /**
   * Get example programs
   */
  getExamples: async (): Promise<any> => {
    return await authFetch('/api/v2/nexuslang/examples')
  },
}

// ====== Projects API ======

export interface Project {
  id: string
  name: string
  description?: string
  visibility: string
  stars_count: number
  forks_count: number
  created_at: string
  updated_at: string
  file_count: number
}

export interface CreateProjectData {
  name: string
  description?: string
  visibility?: string
}

export const projects = {
  /**
   * List user's projects
   */
  list: async (): Promise<Project[]> => {
    return await authFetch('/api/v2/ide/projects')
  },
  
  /**
   * Create a new project
   */
  create: async (data: CreateProjectData): Promise<Project> => {
    return await authFetch('/api/v2/ide/projects', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  },
  
  /**
   * Get project details
   */
  get: async (projectId: string): Promise<Project> => {
    return await authFetch(`/api/v2/ide/projects/${projectId}`)
  },
  
  /**
   * Update project
   */
  update: async (projectId: string, data: Partial<CreateProjectData>): Promise<Project> => {
    return await authFetch(`/api/v2/ide/projects/${projectId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  },
  
  /**
   * Delete project
   */
  delete: async (projectId: string): Promise<void> => {
    await authFetch(`/api/v2/ide/projects/${projectId}`, {
      method: 'DELETE',
    })
  },
}

// ====== Files API ======

export interface File {
  id: string
  project_id: string
  path: string
  content: string
  size_bytes: number
  version: number
  created_at: string
  updated_at: string
}

export interface CreateFileData {
  path: string
  content?: string
}

export const files = {
  /**
   * List files in a project
   */
  list: async (projectId: string): Promise<File[]> => {
    return await authFetch(`/api/v2/ide/projects/${projectId}/files`)
  },
  
  /**
   * Create a new file
   */
  create: async (projectId: string, data: CreateFileData): Promise<File> => {
    return await authFetch(`/api/v2/ide/projects/${projectId}/files`, {
      method: 'POST',
      body: JSON.stringify(data),
    })
  },
  
  /**
   * Get file content
   */
  get: async (fileId: string): Promise<File> => {
    return await authFetch(`/api/v2/ide/files/${fileId}`)
  },
  
  /**
   * Update file content (save)
   */
  update: async (fileId: string, content: string): Promise<File> => {
    return await authFetch(`/api/v2/ide/files/${fileId}`, {
      method: 'PUT',
      body: JSON.stringify({ content }),
    })
  },
  
  /**
   * Delete file
   */
  delete: async (fileId: string): Promise<void> => {
    await authFetch(`/api/v2/ide/files/${fileId}`, {
      method: 'DELETE',
    })
  },
}

// ====== Export all API functions ======

export default {
  auth,
  nexuslang,
  projects,
  files,
}


"""Grokopedia services."""
from .search import SemanticSearch, get_search_engine

__all__ = ['SemanticSearch', 'get_search_engine']


/**
 * API Client for NexusLang v2 Platform
 * Handles all backend communication
 */

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export class APIClient {
  private baseURL: string
  private token: string | null = null

  constructor(baseURL: string = API_URL) {
    this.baseURL = baseURL
    this.loadToken()
  }

  private loadToken() {
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('auth_token')
    }
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...((options.headers as Record<string, string>) || {}),
    }

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`
    }

    const response = await fetch(`${this.baseURL}${endpoint}`, {
      ...options,
      headers,
    })

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Request failed' }))
      throw new Error(error.error || `HTTP ${response.status}`)
    }

    return response.json()
  }

  // Authentication
  async login(email: string, password: string) {
    const data = await this.request<{ access_token: string; user_id: string }>(
      '/api/v2/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }
    )
    this.token = data.access_token
    localStorage.setItem('auth_token', data.access_token)
    return data
  }

  async register(email: string, username: string, password: string) {
    const data = await this.request<{ access_token: string; user_id: string }>(
      '/api/v2/auth/register',
      {
        method: 'POST',
        body: JSON.stringify({ email, username, password }),
      }
    )
    this.token = data.access_token
    localStorage.setItem('auth_token', data.access_token)
    return data
  }

  async logout() {
    await this.request('/api/v2/auth/logout', { method: 'POST' })
    this.token = null
    localStorage.removeItem('auth_token')
  }

  // NexusLang
  async runCode(code: string, compileToBinary: boolean = false) {
    return this.request('/api/v2/nexuslang/run', {
      method: 'POST',
      body: JSON.stringify({ code, compile_to_binary: compileToBinary }),
    })
  }

  async compileCode(code: string) {
    return this.request('/api/v2/nexuslang/compile', {
      method: 'POST',
      body: JSON.stringify({ code }),
    })
  }

  async analyzeCode(code: string) {
    return this.request('/api/v2/nexuslang/analyze', {
      method: 'POST',
      body: JSON.stringify({ code }),
    })
  }

  async getExamples() {
    return this.request('/api/v2/nexuslang/examples')
  }

  // Grokopedia
  async searchKnowledge(query: string) {
    return this.request(`/api/v2/grokopedia/search?q=${encodeURIComponent(query)}`)
  }

  async getKnowledgeEntry(entryId: string) {
    return this.request(`/api/v2/grokopedia/entries/${entryId}`)
  }

  // Billing
  async getSubscription() {
    return this.request('/api/v2/billing/subscriptions')
  }

  async subscribe(tier: string) {
    return this.request('/api/v2/billing/subscribe', {
      method: 'POST',
      body: JSON.stringify({ tier }),
    })
  }

  async getCredits() {
    return this.request('/api/v2/billing/credits')
  }

  async buyCredits(amount: number) {
    return this.request('/api/v2/billing/buy-credits', {
      method: 'POST',
      body: JSON.stringify({ amount }),
    })
  }

  // Community
  async getPosts() {
    return this.request('/api/v2/community/posts')
  }

  async createPost(title: string, content: string, tags: string[]) {
    return this.request('/api/v2/community/posts', {
      method: 'POST',
      body: JSON.stringify({ title, content, tags }),
    })
  }

  async getPublicProjects() {
    return this.request('/api/v2/community/projects/public')
  }
}

// Export singleton instance
export const apiClient = new APIClient()


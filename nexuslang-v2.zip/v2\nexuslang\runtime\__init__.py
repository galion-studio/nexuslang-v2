"""Runtime library for NexusLang"""

from nexuslang.runtime.builtins import get_builtins

__all__ = ["get_builtins"]


"""IDE services."""
# Project and file management services


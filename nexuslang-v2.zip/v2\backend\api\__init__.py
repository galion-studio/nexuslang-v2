"""
API routers for NexusLang v2 Platform.
Each router handles a specific domain of functionality.
"""


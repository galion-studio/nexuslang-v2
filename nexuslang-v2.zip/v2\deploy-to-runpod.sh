#!/bin/bash
# NexusLang v2 - Simple RunPod Deployment
# Run this script on your RunPod instance

echo "🚀 NexusLang v2 - RunPod Deployment"
echo "===================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "🔧 Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

echo "✅ Docker and Docker Compose ready"
echo ""

# Generate secrets
echo "🔐 Generating secure secrets..."
JWT_SECRET=$(openssl rand -hex 32)
SECRET_KEY=$(openssl rand -hex 32)

# Create simple environment file
echo "⚙️  Creating environment..."
mkdir -p backend
cat > backend/.env << EOF
DATABASE_URL=sqlite+aiosqlite:///./nexuslang_dev.db
JWT_SECRET=${JWT_SECRET}
SECRET_KEY=${SECRET_KEY}
DEBUG=true
CORS_ORIGINS=["*"]
OPENAI_API_KEY=
EOF

echo "✅ Environment configured"
echo ""

# Start services
echo "🚀 Starting NexusLang v2..."
docker-compose up -d

echo ""
echo "⏳ Waiting for services to start..."
sleep 15

# Check status
echo ""
echo "📊 Checking services..."
docker-compose ps

echo ""
echo "╔════════════════════════════════════════════════╗"
echo "║  ✅ DEPLOYMENT COMPLETE!                        ║"
echo "╚════════════════════════════════════════════════╝"
echo ""
echo "🌐 Access your platform:"
echo "   Frontend: http://<your-runpod-ip>:3000"
echo "   Backend:  http://<your-runpod-ip>:8000"
echo "   API Docs: http://<your-runpod-ip>:8000/docs"
echo ""
echo "📝 Get your RunPod IP from the dashboard"
echo ""
echo "🎉 Ready to code with NexusLang v2!"


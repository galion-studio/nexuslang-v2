"""CLI module for NexusLang"""

from nexuslang.cli.cli import main

__all__ = ["main"]


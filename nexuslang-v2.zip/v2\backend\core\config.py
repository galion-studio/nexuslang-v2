"""
Configuration management for NexusLang v2 Backend.
Loads settings from environment variables.
"""

from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.
    Uses Pydantic for validation and type checking.
    """
    
    # Application
    APP_NAME: str = "NexusLang v2"
    APP_VERSION: str = "2.0.0-beta"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"
    
    # Security
    SECRET_KEY: str = "dev-secret-key-change-in-production"
    JWT_SECRET: str = "jwt-secret-key-for-development"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = 24
    
    # Database (defaults to SQLite for easy development, PostgreSQL for RunPod)
    # For RunPod: Uses shared Galion PostgreSQL with separate database
    DATABASE_URL: str = "sqlite+aiosqlite:///./nexuslang_dev.db"
    POSTGRES_USER: str = "nexus"
    POSTGRES_PASSWORD: str = "nexuspass"
    POSTGRES_DB: str = "nexuslang_v2"  # Separate from Galion's database
    POSTGRES_HOST: str = "galion-postgres"  # Connect to existing Galion PostgreSQL
    POSTGRES_PORT: int = 5432
    
    # Redis (optional) - For RunPod: Use DB 1 to avoid conflict with Galion (DB 0)
    REDIS_URL: str = "redis://localhost:6379/1"  # DB 1 for NexusLang
    REDIS_PASSWORD: str = ""
    REDIS_HOST: str = "galion-redis"  # Connect to existing Galion Redis
    REDIS_PORT: int = 6379
    
    # Elasticsearch
    ELASTICSEARCH_URL: str = "http://elasticsearch:9200"
    
    # OpenAI (optional)
    OPENAI_API_KEY: str = ""
    OPENAI_ORG_ID: str = ""
    
    # Shopify (optional)
    SHOPIFY_API_KEY: str = ""
    SHOPIFY_API_SECRET: str = ""
    SHOPIFY_ACCESS_TOKEN: str = ""
    SHOPIFY_WEBHOOK_SECRET: str = ""
    SHOPIFY_STORE_URL: str = ""
    
    # Billing
    FREE_TIER_CREDITS: int = 100
    PRO_TIER_CREDITS: int = 10000
    ENTERPRISE_TIER_CREDITS: int = 999999
    CREDIT_COST_PER_1K_TOKENS: int = 1
    
    # Voice
    WHISPER_MODEL: str = "base"
    WHISPER_DEVICE: str = "cpu"
    TTS_MODEL: str = "tts_models/en/ljspeech/tacotron2-DDC"
    TTS_DEVICE: str = "cpu"
    
    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:3001"]
    CORS_ALLOW_CREDENTIALS: bool = True
    
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_PER_HOUR: int = 1000
    RATE_LIMIT_PER_DAY: int = 10000
    
    # Feature Flags
    ENABLE_GROKOPEDIA: bool = True
    ENABLE_VOICE: bool = True
    ENABLE_COMMUNITY: bool = True
    ENABLE_BILLING: bool = True
    
    # Storage (S3-compatible)
    S3_ENDPOINT: str = ""
    S3_BUCKET: str = "nexuslang-storage"
    S3_ACCESS_KEY: str = ""
    S3_SECRET_KEY: str = ""
    
    # Email
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = "noreply@nexuslang.dev"
    
    # Monitoring
    SENTRY_DSN: str = ""
    SENTRY_ENVIRONMENT: str = "development"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Create global settings instance
settings = Settings()


'use client'

import { useState } from 'react'
import { Search, Book, CheckCircle, TrendingUp } from 'lucide-react'

export default function GrokopediaPage() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = async () => {
    if (!query.trim()) return

    setIsSearching(true)

    try {
      const response = await fetch(`/api/v2/grokopedia/search?q=${encodeURIComponent(query)}`)
      const data = await response.json()
      setResults(data.results || [])
    } catch (error) {
      console.error('Search failed:', error)
    } finally {
      setIsSearching(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-900 to-black">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Book className="text-blue-400" size={32} />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Grokopedia
                </h1>
                <p className="text-sm text-zinc-400">Universal AI Knowledge Base</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Search Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Search Bar */}
          <div className="relative mb-12">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-zinc-400" size={20} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Search for any concept, theory, or topic..."
              className="w-full pl-12 pr-4 py-4 bg-zinc-900 border border-zinc-800 rounded-lg text-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              onClick={handleSearch}
              disabled={isSearching}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition disabled:opacity-50"
            >
              {isSearching ? 'Searching...' : 'Search'}
            </button>
          </div>

          {/* Featured Topics */}
          {results.length === 0 && !isSearching && (
            <div className="space-y-8">
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <TrendingUp size={20} className="text-green-400" />
                  Trending Topics
                </h2>
                <div className="grid md:grid-cols-3 gap-4">
                  {TRENDING_TOPICS.map((topic) => (
                    <div
                      key={topic}
                      onClick={() => {
                        setQuery(topic)
                        handleSearch()
                      }}
                      className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg hover:border-zinc-700 cursor-pointer transition"
                    >
                      <p className="font-medium">{topic}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-4">Popular Categories</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {CATEGORIES.map((category) => (
                    <div
                      key={category.name}
                      className="p-6 bg-zinc-900 border border-zinc-800 rounded-lg hover:border-zinc-700 transition text-center"
                    >
                      <div className="text-3xl mb-2">{category.icon}</div>
                      <h3 className="font-semibold mb-1">{category.name}</h3>
                      <p className="text-sm text-zinc-400">{category.count} entries</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Search Results */}
          {results.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">
                Found {results.length} results for "{query}"
              </h2>
              {results.map((result, index) => (
                <div
                  key={result.id || index}
                  className="p-6 bg-zinc-900 border border-zinc-800 rounded-lg hover:border-zinc-700 transition"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-bold text-blue-400 flex items-center gap-2">
                      {result.title}
                      {result.verified && (
                        <CheckCircle size={18} className="text-green-400" />
                      )}
                    </h3>
                    {result.similarity && (
                      <span className="text-sm text-zinc-400">
                        {(result.similarity * 100).toFixed(0)}% match
                      </span>
                    )}
                  </div>
                  <p className="text-zinc-300 mb-4">{result.summary}</p>
                  <div className="flex items-center gap-4 text-sm text-zinc-400">
                    {result.tags && result.tags.map((tag: string) => (
                      <span
                        key={tag}
                        className="px-2 py-1 bg-zinc-800 rounded"
                      >
                        {tag}
                      </span>
                    ))}
                    <span>👁 {result.views_count || 0} views</span>
                    <span>👍 {result.upvotes_count || 0} upvotes</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* No Results */}
          {results.length === 0 && isSearching === false && query && (
            <div className="text-center py-12">
              <p className="text-xl text-zinc-400 mb-4">
                No results found for "{query}"
              </p>
              <p className="text-zinc-500">
                Try different keywords or browse categories above
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const TRENDING_TOPICS = [
  'Quantum Computing',
  'Machine Learning',
  'Blockchain',
  'Neural Networks',
  'Artificial Intelligence',
  'Cryptography'
]

const CATEGORIES = [
  { name: 'Science', icon: '🔬', count: 1234 },
  { name: 'Technology', icon: '💻', count: 2341 },
  { name: 'Mathematics', icon: '📐', count: 891 },
  { name: 'Physics', icon: '⚛️', count: 756 },
  { name: 'Biology', icon: '🧬', count: 634 },
  { name: 'Chemistry', icon: '⚗️', count: 523 },
  { name: 'Engineering', icon: '⚙️', count: 445 },
  { name: 'Philosophy', icon: '🤔', count: 321 }
]


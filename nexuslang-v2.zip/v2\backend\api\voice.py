"""
Voice API routes.
Handles speech-to-text, text-to-speech, and voice cloning.
"""

from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
from typing import Optional

from ..services.voice.stt_service import get_stt_service
from ..services.voice.tts_service import get_tts_service

router = APIRouter()

class TTSRequest(BaseModel):
    text: str
    voice_id: Optional[str] = None
    emotion: Optional[str] = None
    speed: float = 1.0

@router.post("/stt")
async def speech_to_text(
    audio: UploadFile = File(...),
    language: Optional[str] = None
):
    """Convert speech to text using Whisper."""
    if not audio.content_type.startswith('audio/'):
        raise HTTPException(400, "File must be audio")
    
    # Read audio data
    audio_data = await audio.read()
    
    # Transcribe
    stt_service = get_stt_service()
    result = await stt_service.transcribe(audio_data, language)
    
    return result

@router.post("/tts")
async def text_to_speech(request: TTSRequest):
    """Convert text to speech using TTS."""
    if not request.text.strip():
        raise HTTPException(400, "Text cannot be empty")
    
    # Synthesize speech
    tts_service = get_tts_service()
    audio_data = await tts_service.synthesize(
        request.text,
        request.voice_id,
        request.emotion,
        request.speed
    )
    
    # Save to temp file and return URL
    # TODO: Save to S3 or similar storage
    audio_url = "/audio/generated.wav"
    
    return {
        "audio_url": audio_url,
        "text": request.text,
        "voice_id": request.voice_id or "default"
    }

@router.post("/clone")
async def clone_voice(
    samples: list[UploadFile] = File(...),
    name: str = "custom_voice"
):
    """Clone a voice from samples."""
    if len(samples) < 2:
        raise HTTPException(400, "At least 2 audio samples required")
    
    # Read all samples
    audio_samples = []
    for sample in samples:
        if not sample.content_type.startswith('audio/'):
            raise HTTPException(400, "All files must be audio")
        audio_samples.append(await sample.read())
    
    # Clone voice
    tts_service = get_tts_service()
    voice_id = await tts_service.clone_voice(audio_samples, name)
    
    return {
        "voice_id": voice_id,
        "status": "completed",
        "name": name
    }

@router.get("/voices")
async def list_voices():
    """Get list of available voices."""
    tts_service = get_tts_service()
    voices = await tts_service.list_voices()
    return {"voices": voices}


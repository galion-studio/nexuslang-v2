"""Parser module for AST generation"""

from .parser import Parser

__all__ = ["Parser"]


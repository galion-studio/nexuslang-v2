"""
Backend services for NexusLang v2 Platform.
All service implementations in one place.
"""

from .nexuslang_executor import NexusLangExecutor, get_executor
from .billing.shopify_integration import ShopifyClient, CreditManager, get_shopify_client
from .grokopedia.search import SemanticSearch, get_search_engine
from .voice.stt_service import STTService, get_stt_service
from .voice.tts_service import TTSService, get_tts_service

__all__ = [
    'NexusLangExecutor',
    'get_executor',
    'ShopifyClient',
    'CreditManager',
    'get_shopify_client',
    'SemanticSearch',
    'get_search_engine',
    'STTService',
    'get_stt_service',
    'TTSService',
    'get_tts_service'
]

